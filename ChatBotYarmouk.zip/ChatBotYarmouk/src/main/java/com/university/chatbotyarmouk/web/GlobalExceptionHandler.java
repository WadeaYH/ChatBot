package com.university.chatbotyarmouk.web;

import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
    // TODO: add @ExceptionHandler methods
}
