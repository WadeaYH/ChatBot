package com.university.chatbotyarmouk.service.auth;

public interface SisService {
    // TODO: define methods for validating student credentials and fetching student info
}
