package com.university.chatbotyarmouk.dto.auth;

public class StudentLoginRequest {
    // TODO: add fields
}
