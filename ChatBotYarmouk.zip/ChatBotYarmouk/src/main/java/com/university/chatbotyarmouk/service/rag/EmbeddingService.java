package com.university.chatbotyarmouk.service.rag;

import org.springframework.stereotype.Service;

@Service
public class EmbeddingService {
    // TODO: implement service logic
}
