package com.university.chatbotyarmouk.dto.chat;

public class ChatMessageRequest {
    // TODO: add fields
}
