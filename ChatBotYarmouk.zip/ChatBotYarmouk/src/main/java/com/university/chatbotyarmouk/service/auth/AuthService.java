package com.university.chatbotyarmouk.service.auth;

import org.springframework.stereotype.Service;

@Service
public class AuthService {
    // TODO: implement service logic
}
