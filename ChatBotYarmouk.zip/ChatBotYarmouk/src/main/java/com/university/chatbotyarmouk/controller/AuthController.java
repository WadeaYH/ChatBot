package com.university.chatbotyarmouk.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthController {
    // TODO: add endpoints
}
