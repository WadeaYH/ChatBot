package com.university.chatbotyarmouk.dto.student;

public class StudentAttendanceResponse {
    // TODO: add fields
}
