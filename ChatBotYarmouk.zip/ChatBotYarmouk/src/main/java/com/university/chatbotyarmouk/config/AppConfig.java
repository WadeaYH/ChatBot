package com.university.chatbotyarmouk.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    // TODO: add beans/configuration
}
