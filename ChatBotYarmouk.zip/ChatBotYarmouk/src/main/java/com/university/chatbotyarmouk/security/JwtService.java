package com.university.chatbotyarmouk.security;

import org.springframework.stereotype.Service;

@Service
public class JwtService {
    // TODO: implement service logic
}
