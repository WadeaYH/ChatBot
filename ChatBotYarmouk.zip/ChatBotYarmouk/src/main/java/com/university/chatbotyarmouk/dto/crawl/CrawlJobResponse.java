package com.university.chatbotyarmouk.dto.crawl;

public class CrawlJobResponse {
    // TODO: add fields
}
