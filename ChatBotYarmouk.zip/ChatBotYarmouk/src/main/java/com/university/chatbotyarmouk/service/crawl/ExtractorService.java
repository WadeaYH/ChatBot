package com.university.chatbotyarmouk.service.crawl;

import org.springframework.stereotype.Service;

@Service
public class ExtractorService {
    // TODO: implement service logic
}
