package com.university.chatbotyarmouk.service.rag;

import org.springframework.stereotype.Service;

@Service
public class VectorSearchService {
    // TODO: implement service logic
}
