package com.university.chatbotyarmouk.dto.chat;

public class SessionWithMessagesResponse {
    // TODO: add fields
}
