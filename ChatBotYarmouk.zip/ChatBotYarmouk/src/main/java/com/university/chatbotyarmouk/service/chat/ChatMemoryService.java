package com.university.chatbotyarmouk.service.chat;

import org.springframework.stereotype.Service;

@Service
public class ChatMemoryService {
    // TODO: implement service logic
}
