package com.university.chatbotyarmouk.dto.chat;

public class SessionResponse {
    // TODO: add fields
}
