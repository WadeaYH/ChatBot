package com.university.chatbotyarmouk.security;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SecurityConfig {
    // TODO: add beans/configuration
}
