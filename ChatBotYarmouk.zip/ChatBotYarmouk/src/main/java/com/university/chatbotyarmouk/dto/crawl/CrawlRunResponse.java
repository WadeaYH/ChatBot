package com.university.chatbotyarmouk.dto.crawl;

public class CrawlRunResponse {
    // TODO: add fields
}
