package com.university.chatbotyarmouk.repository;



import com.university.chatbotyarmouk.entity.CrawlJob;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CrawlJobRepository extends JpaRepository<CrawlJob, Long> {
}
