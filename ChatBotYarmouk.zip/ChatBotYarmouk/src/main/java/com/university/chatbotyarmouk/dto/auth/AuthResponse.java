package com.university.chatbotyarmouk.dto.auth;

public class AuthResponse {
    // TODO: add fields
}
