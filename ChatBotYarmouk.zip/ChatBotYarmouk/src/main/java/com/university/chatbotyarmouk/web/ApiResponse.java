package com.university.chatbotyarmouk.web;

public class ApiResponse {
    // TODO: add fields
}
