package com.university.chatbotyarmouk.dto.auth;

public class GuestAuthRequest {
    // TODO: add fields
}
