package com.university.chatbotyarmouk.service.rag;

import org.springframework.stereotype.Service;

@Service
public class GeminiClient {
    // TODO: implement service logic
}
