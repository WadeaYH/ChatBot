package com.university.chatbotyarmouk.dto.student;

public class StudentGpaResponse {
    // TODO: add fields
}
