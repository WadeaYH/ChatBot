package com.university.chatbotyarmouk.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class CorsConfig {
    // TODO: add beans/configuration
}
