package com.university.chatbotyarmouk.service.crawl;

import org.springframework.stereotype.Service;

@Service
public class CrawlService {
    // TODO: implement service logic
}
