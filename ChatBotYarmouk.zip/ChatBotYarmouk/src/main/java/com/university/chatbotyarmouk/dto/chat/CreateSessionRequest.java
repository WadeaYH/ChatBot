package com.university.chatbotyarmouk.dto.chat;

public class CreateSessionRequest {
    // TODO: add fields
}
