package com.university.chatbotyarmouk.dto.student;

public class StudentProfileResponse {
    // TODO: add fields
}
