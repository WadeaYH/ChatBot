package com.university.chatbotyarmouk.service.auth;

import org.springframework.stereotype.Service;

@Service
public class SisMockService {
    // TODO: implement service logic
}
