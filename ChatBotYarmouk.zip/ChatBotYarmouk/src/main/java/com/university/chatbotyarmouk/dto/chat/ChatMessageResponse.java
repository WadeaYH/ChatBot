package com.university.chatbotyarmouk.dto.chat;

public class ChatMessageResponse {
    // TODO: add fields
}
