package com.university.chatbotyarmouk.service.chat;

import org.springframework.stereotype.Service;

@Service
public class ChatService {
    // TODO: implement service logic
}
