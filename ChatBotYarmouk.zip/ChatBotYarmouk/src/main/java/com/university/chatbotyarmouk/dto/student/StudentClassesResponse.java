package com.university.chatbotyarmouk.dto.student;

public class StudentClassesResponse {
    // TODO: add fields
}
