package com.university.chatbotyarmouk.service.audit;

import org.springframework.stereotype.Service;

@Service
public class AuditLogService {
    // TODO: implement service logic
}
