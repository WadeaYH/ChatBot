package com.university.chatbotyarmouk.service.crawl;

import org.springframework.stereotype.Service;

@Service
public class CrawlScheduler {
    // TODO: implement service logic
}
